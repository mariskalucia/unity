using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pistol : MonoBehaviour
{
    public float blastForce;
    public GameObject bullutPrefab;
    public Transform spawnPoint;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        void Fire()
        {
            GameObject bulluts = Instantiate(bullutPrefab, spawnPoint.position, spawnPoint.rotation);
            bulluts.GetComponent<Rigidbody>().AddForce(spawnPoint.transform.forward * blastForce, ForceMode.Impulse);
        }

        if (Input.GetMouseButtonDown(0))
        {
            Fire();
        }

    }
}
