using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class JMFinsish : MonoBehaviour
{
    public Text timerText;
    public float startTime = 0.0f;
    public bool finnished = false;

    public Text highScoreText;
    public Text scoreText;

    // Start is called before the first frame update
    void Start()
    {
        timerText.text = startTime.ToString("f2");
    }

    // Update is called once per frame
    void Update()
    {
        if (finnished)
        {
            float highscore = 0;
            float score = startTime;
            scoreText.text = "Score: " + score.ToString("f2");
            if (highscore > score)
            {
                highScoreText.text = "Highscore: " + highscore.ToString("f2");
            }
            else
            {
                highscore += score;
                highScoreText.text = "Highscore: " + highscore.ToString("f2");
            }
            return;
        }

        startTime += Time.deltaTime;
        timerText.text = startTime.ToString("f2");
    }

    public void Finnish()
    {
        finnished = true;
        timerText.color = Color.red;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "Player")
        {
            SendMessage("Finnish");
        }
    }
}
