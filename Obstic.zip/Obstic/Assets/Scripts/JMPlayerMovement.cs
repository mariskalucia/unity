using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JMPlayerMovement : MonoBehaviour
{
    public float movementSpeed = 10.0f;
    public float rotationSpeed = 100.0f;

    public float jumpHeight = 50;
    public bool isGrounded;

    private Rigidbody rb;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {


        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.DownArrow))
        {
            float translation = Input.GetAxis("Vertical") * movementSpeed;
            translation *= Time.deltaTime;
            transform.Translate(0, 0, translation);
        }

        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.RightArrow))
        {
            float rotation = Input.GetAxis("Horizontal") * rotationSpeed;
            rotation *= Time.deltaTime;
            transform.Rotate(0, rotation, 0);
        }

        if (Input.GetKey(KeyCode.LeftShift))
        {
            float translation = Input.GetAxis("Vertical") * movementSpeed * 2;
            translation *= Time.deltaTime;
            transform.Translate(0, 0, translation);
        }

        if (isGrounded)
        {
            if (Input.GetKey(KeyCode.Space))
            {
                rb.AddForce(Vector3.up * jumpHeight);
            }
        }
    }

    void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.name == "JumpPad")
        {
            isGrounded = true;
        }
        if (other.gameObject.name == "StartFloor")
        {
            isGrounded = true;
        }
    }

    void OnCollisionExit(Collision other)
    {
        if (other.gameObject.name == "JumpPad")
        {
            isGrounded = false;
        }
        if (other.gameObject.name == "StartFloor")
        {
            isGrounded = false;
        }
    }
}
